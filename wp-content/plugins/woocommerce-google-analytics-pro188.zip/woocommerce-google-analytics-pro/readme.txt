=== WooCommerce Google Analytics Pro ===
Author: skyverge
Tags: woocommerce
Requires at least: 4.4
Tested up to: 5.3.2
Requires PHP: 5.6

Supercharge your Google Analytics tracking with enhanced eCommerce tracking and custom event tracking

See https://docs.woocommerce.com/document/woocommerce-google-analytics-pro/ for full documentation.

== Installation ==

1. Upload the entire 'woocommerce-google-analytics-pro' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
